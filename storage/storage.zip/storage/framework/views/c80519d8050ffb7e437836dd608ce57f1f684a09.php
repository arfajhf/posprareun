

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Laporan <?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Laporan <?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <form action="/laporan/penjualan_harian_cari" method="get">
                                <div class="row">
                                    <div class="col-md-1">
                                        <label for="tanggal">Pilih Tanggal</label>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal" class="form-control form-control-sm"
                                                id="tanggal" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                        <a href="/laporan/penjualan_harian" class="btn btn-primary">Refresh</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>No Invoice</th>
                                        <th>Pelanggan</th>
                                        <th>Jenis Pembayaran</th>
                                        <th>Nama Bank</th>
                                        <th>Bukti Transfer</th>
                                        <th>Total Pembayaran</th>
                                        <th>Biaya Pengiriman</th>
                                        <th>Sub Total</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><a href="/laporan/detail_penjualan/<?php echo e($item->no_invoice); ?>"
                                                target="_blank"><?php echo e($item->no_invoice); ?></a></td>
                                        <?php if($item->pelanggan_id == ''): ?>
                                        <td></td>
                                        <?php else: ?>
                                        <td><?php echo e($item->pelanggan->nama); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e(ucfirst($item->jenis)); ?></td>
                                        <td><?php echo e($item->jenis_bank); ?></td>
                                        <?php if($item->bukti_transfer == ''): ?>
                                        <td></td>
                                        <?php else: ?>
                                        <td>
                                            <a href="<?php echo e(asset('bukti_transfer/' . $item->bukti_transfer)); ?>"
                                                target="_blank">
                                                <img src="<?php echo e(asset('bukti_transfer/' . $item->bukti_transfer)); ?>"
                                                    width="50">
                                            </a>
                                        </td>
                                        <?php endif; ?>
                                        <td><?php echo e(number_format($item->total_pembayaran, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->biaya_pengiriman, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->sub_total, 0, ',', '.')); ?></td>
                                        <td>
                                            <a href="/penjualan/struk/<?php echo e($item->id); ?>"
                                                class="btn btn-secondary text-white btn-sm" target="_blank"><i
                                                    class="fas fa-print"></i> Struk</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bisnisna/pos.preneur.co.id/resources/views/laporan/penjualan_harian.blade.php ENDPATH**/ ?>