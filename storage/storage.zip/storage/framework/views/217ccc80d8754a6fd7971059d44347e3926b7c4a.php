

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Tambah <?php echo e($title); ?> Baru</h3>
                        </div>
                        <form action="/barang/update/<?php echo e($barang->id); ?>" method="POST">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="kode_barang">Kode Barang</label>
                                            <input type="text" name="kode_barang" class="form-control form-control-sm"
                                                id="kode_barang"
                                                value="<?php echo e(old('kode_barang') == '' ? $barang->kode_barang : old('kode_barang')); ?>"
                                                required>
                                            <?php $__errorArgs = ['kode_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="nama_barang">Nama Barang</label>
                                            <input type="text" name="nama_barang" class="form-control form-control-sm"
                                                id="nama_barang"
                                                value="<?php echo e(old('nama_barang') == '' ? $barang->nama_barang : old('nama_barang')); ?>"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="kategori_id">Kategori</label>
                                            <select name="kategori_id" id="kategori_id"
                                                class="form-control form-control-sm">
                                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"
                                                    <?php echo e($barang->kategori_id == $item->id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="harga_beli">Harga Beli</label>
                                            <input type="text" class="form-control form-control-sm" id="harga_beli"
                                                autocomplete="off"
                                                value="<?php echo e(old('harga_beli') == '' ? $barang->harga_beli : old('harga_beli')); ?>"
                                                required>
                                            <input type="hidden" name="harga_beli" id="harga_beli1"
                                                value="<?php echo e(old('harga_beli') == '' ? $barang->harga_beli : old('harga_beli')); ?>"
                                                required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="harga_ecer">Harga Ecer</label>
                                            <input type="text" class="form-control form-control-sm" id="harga_ecer"
                                                autocomplete="off"
                                                value="<?php echo e(old('harga_ecer') == '' ? $barang->harga_ecer : old('harga_ecer')); ?>"
                                                required>
                                            <input type="hidden" name="harga_ecer" id="harga_ecer1"
                                                value="<?php echo e(old('harga_ecer') == '' ? $barang->harga_ecer : old('harga_ecer')); ?>"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="harga_grosir">Harga Grosir</label>
                                            <input type="text" class="form-control form-control-sm" id="harga_grosir"
                                                autocomplete="off"
                                                value="<?php echo e(old('harga_grosir') == '' ? $barang->harga_grosir : old('harga_grosir')); ?>"
                                                required>
                                            <input type="hidden" name="harga_grosir" id="harga_grosir1"
                                                value="<?php echo e(old('harga_grosir') == '' ? $barang->harga_grosir : old('harga_grosir')); ?>"
                                                required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="harga_agen">Harga Agen</label>
                                            <input type="text" class="form-control form-control-sm" autocomplete="off"
                                                id="harga_agen"
                                                value="<?php echo e(old('harga_agen') == '' ? $barang->harga_agen : old('harga_agen')); ?>"
                                                required>
                                            <input type="hidden" name="harga_agen" id="harga_agen1"
                                                value="<?php echo e(old('harga_agen') == '' ? $barang->harga_agen : old('harga_agen')); ?>"
                                                required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="profit_harga_ecer">Profit Harga Ecer</label>
                                            <input type="text" class="form-control form-control-sm"
                                                id="profit_harga_ecer"
                                                value="<?php echo e(old('profit_harga_ecer') == '' ? $barang->profit_harga_ecer : old('profit_harga_ecer')); ?>"
                                                readonly required>
                                            <input type="hidden" name="profit_harga_ecer" id="profit_harga_ecer1"
                                                value="<?php echo e(old('profit_harga_ecer') == '' ? $barang->profit_harga_ecer : old('profit_harga_ecer')); ?>"
                                                readonly required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="profit_harga_grosir">Profit Harga Grosir</label>
                                            <input type="text" name="profit_harga_grosir"
                                                class="form-control form-control-sm" id="profit_harga_grosir"
                                                value="<?php echo e(old('profit_harga_grosir') == '' ? $barang->profit_harga_grosir : old('profit_harga_grosir')); ?>"
                                                readonly required>
                                            <input type="hidden" name="profit_harga_grosir" id="profit_harga_grosir1"
                                                value="<?php echo e(old('profit_harga_grosir') == '' ? $barang->profit_harga_grosir : old('profit_harga_grosir')); ?>"
                                                readonly required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="profit_harga_agen">Profit Harga Agen</label>
                                            <input type="text" name="profit_harga_agen"
                                                class="form-control form-control-sm" id="profit_harga_agen"
                                                value="<?php echo e(old('profit_harga_agen') == '' ? $barang->profit_harga_agen : old('profit_harga_agen')); ?>"
                                                readonly required>
                                            <input type="hidden" name="profit_harga_agen" id="profit_harga_agen1"
                                                value="<?php echo e(old('profit_harga_agen') == '' ? $barang->profit_harga_agen : old('profit_harga_agen')); ?>"
                                                readonly required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="deskripsi">Deskripsi</label>
                                            <input type="text" name="deskripsi" class="form-control form-control-sm"
                                                value="<?php echo e(old('deskripsi') == '' ? $barang->deskripsi : old('deskripsi')); ?>"
                                                id="deskripsi">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="stok">Stok</label>
                                            <input type="text" name="stok" class="form-control form-control-sm"
                                                value="<?php echo e(old('stok') == '' ? $barang->stok : old('stok')); ?>"
                                                id="stok">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="stok_minimal">Minimal Stok</label>
                                            <input type="text" name="stok_minimal" class="form-control form-control-sm"
                                                value="<?php echo e(old('stok_minimal') == '' ? $barang->stok_minimal : old('stok_minimal')); ?>"
                                                id="stok_minimal">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                <a href="/barang" class="btn btn-light btn-sm">kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    $('#harga_beli').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let harga_beli1 = $(this).val().split('.');
        $('#harga_beli1').val(harga_beli1.join(""));
    })

    $('#harga_ecer').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let harga_ecer1 = $(this).val().split('.');
        $('#harga_ecer1').val(harga_ecer1.join(""));

        let harga_beli1 = document.getElementById('harga_beli1').value;
        let harga_ecer2 = document.getElementById('harga_ecer1').value;
        let profit_harga_ecer = document.getElementById('profit_harga_ecer');
        let profit_harga_ecer1 = document.getElementById('profit_harga_ecer1');

        hasil = parseInt(harga_ecer2) - parseInt(harga_beli1);
        profit_harga_ecer.value = parseInt(hasil).toLocaleString('id-ID');
        profit_harga_ecer1.value = hasil;
    })

    $('#harga_grosir').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let harga_grosir1 = $(this).val().split('.');
        $('#harga_grosir1').val(harga_grosir1.join(""));

        let harga_beli1 = document.getElementById('harga_beli1').value;
        let harga_grosir2 = document.getElementById('harga_grosir1').value;
        let profit_harga_grosir = document.getElementById('profit_harga_grosir');
        let profit_harga_grosir1 = document.getElementById('profit_harga_grosir1');

        hasil = parseInt(harga_grosir2) - parseInt(harga_beli1);
        profit_harga_grosir.value = parseInt(hasil).toLocaleString('id-ID');
        profit_harga_grosir1.value = hasil;
    })

    $('#harga_agen').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let harga_agen1 = $(this).val().split('.');
        $('#harga_agen1').val(harga_agen1.join(""));

        let harga_beli1 = document.getElementById('harga_beli1').value;
        let harga_agen2 = document.getElementById('harga_agen1').value;
        let profit_harga_agen = document.getElementById('profit_harga_agen');
        let profit_harga_agen1 = document.getElementById('profit_harga_agen1');
        let hasil = parseInt(harga_agen2) - parseInt(harga_beli1);

        if (!isNaN(hasil)) {
            profit_harga_agen.value = parseInt(hasil).toLocaleString('id-ID');
            profit_harga_agen1.value = hasil;
  		}
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos\resources\views/barang/edit.blade.php ENDPATH**/ ?>