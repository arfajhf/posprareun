

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data <?php echo e($title); ?></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="modal"
                                    data-target="#modalTambah">
                                    <i class="fas fa-plus"></i> Tambah <?php echo e($title); ?> Baru
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Nama</th>
                                        <th>No HP</th>
                                        <th>Email</th>
                                        <th>No Rekening</th>
                                        <th>Atas Nama Rekening</th>
                                        <th>Bank</th>
                                        <th>Kode POS</th>
                                        <th>Alamat</th>
                                        <th>Deskripsi</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->no_hp); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->no_rekening); ?></td>
                                        <td><?php echo e($item->rekening_atas_nama); ?></td>
                                        <td><?php echo e($item->bank); ?></td>
                                        <td><?php echo e($item->kode_pos); ?></td>
                                        <td><?php echo e($item->alamat); ?></td>
                                        <td><?php echo e($item->deskripsi); ?></td>
                                        <td>
                                            <button type="button" id="btn_edit" data-id="<?php echo e($item->id); ?>"
                                                data-nama="<?php echo e($item->nama); ?>" data-no_hp="<?php echo e($item->no_hp); ?>"
                                                data-email="<?php echo e($item->email); ?>"
                                                data-no_rekening="<?php echo e($item->no_rekening); ?>"
                                                data-rekening_atas_nama="<?php echo e($item->rekening_atas_nama); ?>"
                                                data-bank="<?php echo e($item->bank); ?>" data-kode_pos="<?php echo e($item->kode_pos); ?>"
                                                data-alamat="<?php echo e($item->alamat); ?>"
                                                data-deskripsi="<?php echo e($item->deskripsi); ?>"
                                                class="btn btn-warning text-white btn-sm" data-toggle="modal"
                                                data-target="#modal_edit"><i class="fas fa-edit"></i>
                                                Edit</button>
                                            <a href="/supplier/<?php echo e($item->id); ?>/destroy"
                                                onclick="return confirm('Yakin mau dihapus?!')"
                                                class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i>
                                                Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Form Tambah <?php echo e($title); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/supplier" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama">Nama Supplier</label>
                        <input type="text" name="nama" class="form-control form-control-sm" id="nama" required>
                    </div>
                    <div class="form-group">
                        <label for="no_hp">No HP</label>
                        <input type="text" name="no_hp" class="form-control form-control-sm" id="no_hp" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" class="form-control form-control-sm" id="email" required>
                    </div>
                    <div class="form-group">
                        <label for="no_rekening">No Rekening</label>
                        <input type="text" name="no_rekening" class="form-control form-control-sm" id="no_rekening"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="rekening_atas_nama">Atas Nama Rekening</label>
                        <input type="text" name="rekening_atas_nama" class="form-control form-control-sm"
                            id="rekening_atas_nama" required>
                    </div>
                    <div class="form-group">
                        <label for="bank">Bank</label>
                        <input type="text" name="bank" class="form-control form-control-sm" id="bank" required>
                    </div>
                    <div class="form-group">
                        <label for="kode_pos">Kode POS</label>
                        <input type="text" name="kode_pos" class="form-control form-control-sm" id="kode_pos" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" class="form-control form-control-sm" id="alamat" required>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <input type="text" name="deskripsi" class="form-control form-control-sm" id="deskripsi"
                            required>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal_edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Form Edit <?php echo e($title); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" id="formEdit">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="edit_nama">Nama Supplier</label>
                        <input type="text" name="edit_nama" class="form-control form-control-sm" id="edit_nama"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="edit_no_hp">No HP</label>
                        <input type="text" name="edit_no_hp" class="form-control form-control-sm" id="edit_no_hp"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="edit_email">Email</label>
                        <input type="email" name="edit_email" class="form-control form-control-sm" id="edit_email"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="edit_no_rekening">No Rekening</label>
                        <input type="text" name="edit_no_rekening" class="form-control form-control-sm"
                            id="edit_no_rekening" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_rekening_atas_nama">Atas Nama Rekening</label>
                        <input type="text" name="edit_rekening_atas_nama" class="form-control form-control-sm"
                            id="edit_rekening_atas_nama" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_bank">Bank</label>
                        <input type="text" name="edit_bank" class="form-control form-control-sm" id="edit_bank"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="edit_kode_pos">Kode POS</label>
                        <input type="text" name="edit_kode_pos" class="form-control form-control-sm" id="edit_kode_pos"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="edit_alamat">Alamat</label>
                        <input type="text" name="edit_alamat" class="form-control form-control-sm" id="edit_alamat"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="edit_deskripsi">Deskripsi</label>
                        <input type="text" name="edit_deskripsi" class="form-control form-control-sm"
                            id="edit_deskripsi" required>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-primary btn-sm">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).on('click', '#btn_edit', function() {
        let id_supplier = $(this).data('id');
        let nama = $(this).data('nama');
        let no_hp = $(this).data('no_hp');
        let email = $(this).data('email');
        let no_rekening = $(this).data('no_rekening');
        let rekening_atas_nama = $(this).data('rekening_atas_nama');
        let bank = $(this).data('bank');
        let kode_pos = $(this).data('kode_pos');
        let alamat = $(this).data('alamat');
        let deskripsi = $(this).data('deskripsi');

        $('#formEdit').attr('action', '/supplier/'+id_supplier+'/update');
        $('#edit_nama').val(nama);
        $('#edit_no_hp').val(no_hp);
        $('#edit_email').val(email);
        $('#edit_no_rekening').val(no_rekening);
        $('#edit_rekening_atas_nama').val(rekening_atas_nama);
        $('#edit_bank').val(bank);
        $('#edit_kode_pos').val(kode_pos);
        $('#edit_alamat').val(alamat);
        $('#edit_deskripsi').val(deskripsi);
    });
</script>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-laravel-pak-fazar\resources\views/supplier/index.blade.php ENDPATH**/ ?>