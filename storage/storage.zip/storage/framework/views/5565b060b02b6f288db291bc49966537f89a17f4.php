<!DOCTYPE html>
<html>

<head>
    <title>RASH - <?php echo e($penjualan->no_invoice); ?></title>
    <style>
        body {
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            color: #595959;
        }

        table {
            border-collapse: collapse;
        }

        .footer {
            display: flex;
            justify-content: space-between;
        }

        @media  print {
            @page  {
                width: 80mm;
                margin: 0mm
            }

            a {
                display: none;
            }
        }
    </style>
</head>

<body onload="window.print()">

    <a href="/penjualan/<?php echo e(no_invoice()); ?>">Kembali</a>
    <h5>RASH</h5>
    <h5 style="margin-top: -20px">Perum Grand Mayasari Estate Cluster Gracewood Kota Tasikmalaya</h5>

    <table border="0" style="margin-top: -20px;">
        <tr>
            <th align="left">Tanggal</th>
            <td>:</td>
            <td><?php echo e(date('d/m/Y H:i:s', strtotime($penjualan->created_at))); ?></td>
        </tr>
        <tr>
            <th align="left">Kasir</th>
            <td>:</td>
            <td><?php echo e($penjualan->user->name); ?></td>
        </tr>
        <tr>
            <th align="left">No. Invoice</th>
            <td>:</td>
            <td><?php echo e($penjualan->no_invoice); ?></td>
        </tr>
        <tr>
            <th align="left">Pelanggan</th>
            <td>:</td>
            <?php if($penjualan->pelanggan_id == ''): ?>
            <td>Umum</td>
            <?php else: ?>
            <td><?php echo e($penjualan->pelanggan->nama); ?></td>
            <?php endif; ?>
        </tr>
        <tr>
            <th align="left">Jenis</th>
            <td>:</td>
            <td><?php echo e(ucfirst($penjualan->jenis)); ?></td>
        </tr>
        <tr>
            <th align="left">Bank</th>
            <td>:</td>
            <td><?php echo e(ucfirst($penjualan->jenis_bank)); ?></td>
        </tr>
    </table>

    <table border="1" width="100%" style="margin-top: 10px;">
        <tr>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">No</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">KODE BARANG</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">NAMA BARANG</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">JENIS</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">HARGA</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">ITEM</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">POTONGAN</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">TOTAL HARGA</th>
        </tr>
        <?php
        $no = 1;
        ?>
        <?php $__currentLoopData = $detail_penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e($no++); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e($item->kode_barang); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e($item->nama_barang); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e(ucfirst($item->jenis)); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e($item->qty); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e(number_format($item->potongan, 0, ',', '.')); ?></td>
            <td style="border: 2px dashed #aaa; padding: 8px;"><?php echo e(number_format($item->total_harga, 0, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">JUMLAH</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong><?php echo e(number_format($penjualan->total_pembayaran, 0, ',', '.')); ?></strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">BIAYA PENGIRIMAN</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong><?php echo e(number_format($penjualan->biaya_pengiriman, 0, ',', '.')); ?></strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">SUB TOTAL</th>
            <td style="border: 2px dashed #fff; padding: 8px;">

                <strong><?php echo e(number_format($penjualan->sub_total, 0, ',', '.')); ?></strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">TUNAI</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong><?php echo e(number_format($penjualan->pembayaran, 0, ',', '.')); ?></strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">KEMBALIAN</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong><?php echo e(number_format($penjualan->kembalian, 0, ',', '.')); ?></strong></td>
        </tr>
    </table>

    <div class="footer">
        <ul>
            <li>Barang yang rusak dapat dikembalian dengan syarat tertentu</li>
            <li>Selamat berbelanja kembali</li>
            <li>Terima kasih</li>
        </ul>
    </div>



</body>

</html><?php /**PATH E:\laravel\pos-rash\resources\views/penjualan/struk.blade.php ENDPATH**/ ?>