

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Laporan <?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Laporan <?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <form action="/laporan/penjualan_minggu_atau_bulan_cari" method="get">
                                <div class="row">
                                    <div class="col-md-1">
                                        <label>Pilih Tanggal</label>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal_awal" class="form-control form-control-sm"
                                                id="tanggal_awal" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal_akhir" class="form-control form-control-sm"
                                                id="tanggal_akhir" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                        <a href="/laporan/penjualan_minggu_atau_bulan"
                                            class="btn btn-primary">Refresh</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Tanggal : <?php echo e($tanggal_awal1); ?> Sampai <?php echo e($tanggal_akhir1); ?></strong>
                                </div>
                                <div class="col-md-6">
                                    <form action="/laporan/penjualan_minggu_atau_bulan_download" method="post" target="
                                    _blank">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="tanggal_awal" value="<?php echo e($tanggal_awal2); ?>">
                                        <input type="hidden" name="tanggal_akhir" value="<?php echo e($tanggal_akhir2); ?>">
                                        <button type="submit" class="btn btn-success float-right">Download PDF</button>
                                    </form>
                                </div>
                            </div>
                            <table class="table table-bordered table-striped table-hover table-sm mt-2">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>No Invoice</th>
                                        <th>Pelanggan</th>
                                        <th>Jenis Pembayaran</th>
                                        <th>Nama Bank</th>
                                        <th>Bukti Transfer</th>
                                        <th>Total Pembayaran</th>
                                        <th>Biaya Pengiriman</th>
                                        <th>Sub Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $total_pendapatan = 0;
                                    ?>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $total_pendapatan += $item->sub_total;
                                    ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><a href="/laporan/detail_penjualan/<?php echo e($item->no_invoice); ?>"
                                                target="_blank"><?php echo e($item->no_invoice); ?></a></td>
                                        <?php if($item->pelanggan_id == ''): ?>
                                        <td></td>
                                        <?php else: ?>
                                        <td><?php echo e($item->pelanggan->nama); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e(ucfirst($item->jenis)); ?></td>
                                        <td><?php echo e($item->jenis_bank); ?></td>
                                        <?php if($item->bukti_transfer == ''): ?>
                                        <td></td>
                                        <?php else: ?>
                                        <td>
                                            <a href="<?php echo e(asset('bukti_transfer/' . $item->bukti_transfer)); ?>"
                                                target="_blank">
                                                <img src="<?php echo e(asset('bukti_transfer/' . $item->bukti_transfer)); ?>"
                                                    width="50">
                                            </a>
                                        </td>
                                        <?php endif; ?>
                                        <td><?php echo e(number_format($item->total_pembayaran, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->biaya_pengiriman, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->sub_total, 0, ',', '.')); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="8" align="center"><strong>Total Pendapatan</strong></td>
                                        <td><?php echo e(number_format($total_pendapatan, 0, ',', '.')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/penjualan_minggu_atau_bulan_cari.blade.php ENDPATH**/ ?>