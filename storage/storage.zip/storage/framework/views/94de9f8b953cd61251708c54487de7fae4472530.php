

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <div class="text-center">
                                <img class="profile-user-img img-fluid img-circle"
                                    src="<?php echo e(asset('photo/' . auth()->user()->photo)); ?>" alt="User profile picture">
                            </div>

                            <h3 class="profile-username text-center"><?php echo e(auth()->user()->name); ?></h3>

                            <p class="text-muted text-center"><?php echo e(auth()->user()->email); ?></p>

                            <form action="/profile" method="post" class="form-horizontal" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="name" class="col-sm-2 col-form-label">Ubah Nama</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="name" class="form-control" id="name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="email" class="col-sm-2 col-form-label">Ubah Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" name="email" class="form-control" id="email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="photo" class="col-sm-2 col-form-label">Ubah Photo</label>
                                    <div class="col-sm-10">
                                        <input type="file" name="photo" class="form-control" id="photo">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block"><b>Update Profile</b></button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-primary card-outline">
                        <div class="card-body box-profile">
                            <form action="/updatepassword" method="post" class="form-horizontal">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="password" class="col-sm-2 col-form-label">Ubah Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" name="password" class="form-control" id="password"
                                            required>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group row">
                                    <label for="password_confirmation" class="col-sm-2 col-form-label">Konfirmasi
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" name="password_confirmation" class="form-control"
                                            id="password_confirmation" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block"><b>Update Password</b></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos\resources\views/user/profile.blade.php ENDPATH**/ ?>