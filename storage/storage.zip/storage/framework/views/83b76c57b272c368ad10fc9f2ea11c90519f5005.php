

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data <?php echo e($title); ?> Piutang</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>Nama</th>
                                        <th>No Invoice</th>
                                        <th>Sub Total</th>
                                        <th>Sisa Hutang</th>
                                        <th>Tanggal</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $hutang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <?php if($item->pelanggan_id == ''): ?>
                                        <td></td>
                                        <?php else: ?>
                                        <td><?php echo e($item->pelanggan->nama); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($item->no_invoice); ?></td>
                                        <td><?php echo e(number_format($item->sub_total, 0, ',', '.')); ?></td>
                                        <?php
                                        $total_hutang = $item->sub_total - $item->pembayaran;
                                        ?>
                                        <td><?php echo e(number_format($total_hutang, 0, ',', '.')); ?></td>
                                        <td><?php echo e(tanggal_indonesia(date('d-m-Y', strtotime($item->created_at)))); ?></td>
                                        <td>
                                            <?php if($item->status == 0): ?>
                                            <span class="badge badge-pill badge-dark">Belum Lunas</span>
                                            <?php else: ?>
                                            <span class="badge badge-pill badge-success">Sudah Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="/hutang/detail/<?php echo e($item->id); ?>" class="btn btn-secondary btn-sm"
                                                target="_blank">
                                                <i class="fas fa-paper-plane"></i> Detail
                                            </a>
                                            <a href="/hutang/<?php echo e($item->id); ?>/edit"
                                                class="btn btn-warning text-white btn-sm"><i class="fas fa-edit"></i>
                                                Edit</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-rash\resources\views/hutang/index.blade.php ENDPATH**/ ?>