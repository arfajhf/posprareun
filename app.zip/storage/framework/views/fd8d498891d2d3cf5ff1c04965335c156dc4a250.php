<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RASH - LAPORAN KEUNTUNGAN MINGGU/BULAN <?php echo e($tanggal_awal1); ?> SAMPAI <?php echo e($tanggal_akhir1); ?></title>
    <style>
        body {
            font-size: 12px;
        }

        h3 {
            text-align: center;
            margin-top: 0px;
            margin-bottom: 5px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            color: #595959;
        }

        .section2 {
            width: 100%;
            height: 50px;
            font-family: calibri;
            background-color: #7E97AD;
            color: #fff;
        }

        .h2-section2 {
            margin-left: 20px;
            line-height: 50px;
        }

        .section3 {
            margin-top: 10px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table td,
        table th {
            border: 1px solid #ddd;
            padding: 8px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }

        table th {
            background-color: #5a5c69;
            color: #fff;
            text-align: left;
        }

        tr:nth-child(even) {
            background: #E5EAEE;
        }
    </style>
</head>

<body win>
    <section class="section1">
        <h3>LAPORAN KEUNTUNGAN MINGGU/BULAN <?php echo e($tanggal_awal1); ?> SAMPAI <?php echo e($tanggal_akhir1); ?></h3>
    </section>

    <section class="section3">
        <table>
            <tr>
                <th>#</th>
                <th>Tanggal</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Jenis Penjualan</th>
                <th>Harga</th>
                <th>QTY</th>
                <th>Profit</th>
                <th>Potongan</th>
                <th>Keuntungan</th>
            </tr>
            <?php
            $no = 1;
            $total_keuntungan = 0;
            ?>
            <?php $__currentLoopData = $detail_penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $keuntungan = $item->qty * $item->profit - $item->potongan;
            $total_keuntungan += $keuntungan;
            ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e(date('d-m-Y H:i:s', strtotime($item->created_at))); ?></td>
                <td><?php echo e($item->kode_barang); ?></td>
                <td><?php echo e($item->nama_barang); ?></td>
                <td><?php echo e(strtoupper($item->jenis)); ?></td>
                <td><?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                <td><?php echo e($item->qty); ?></td>
                <td><?php echo e(number_format($item->profit, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($item->potongan, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($keuntungan, 0, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="9" align="center"><strong>Total Keuntungan</strong></td>
                <td><?php echo e(number_format($total_keuntungan, 0, ',', '.')); ?></td>
            </tr>
        </table>
        <p><strong>Rumus Keuntungan :</strong> QTY X Profit - Potongan</p>
    </section>
</body>

</html><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/keuntungan_minggu_atau_bulan_download.blade.php ENDPATH**/ ?>