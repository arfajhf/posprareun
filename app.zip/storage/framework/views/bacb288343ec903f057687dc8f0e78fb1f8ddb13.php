

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Laporan <?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Laporan <?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-2">
                                    <label for="">Cari Berdasarkan</label>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <select id="cari_berdasarkan" class="form-control form-control-sm">
                                            <option value="">===</option>
                                            <option value="" data-jenis_cari="semua_data">Semua Data</option>
                                            <option value="" data-jenis_cari="harian">Harian</option>
                                            <option value="" data-jenis_cari="minggu_atau_bulan">Minggu/Bulan</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div id="target"></div>
                            
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped table-hover table-sm">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>KODE BARANG</th>
                                        <th>NAMA BARANG</th>
                                        <th>JENIS</th>
                                        <th>HARGA</th>
                                        <th>PROFIT</th>
                                        <th>QTY</th>
                                        <th>POTONGAN</th>
                                        <th>KEUNTUNGAN</th>
                                    </tr>
                                </thead>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>

<script>
    $(document).on('change', '#cari_berdasarkan', function() {
		//  alert($(this).find(':selected').data('jenis_cari'));
         if ( $(this).find(':selected').data('jenis_cari') == 'semua_data' ) {
            $('#target').html(`
                <a href="/laporan/keuntungan_semua_data" class="btn btn-primary tutup">Cari Semua Data</a>
                <a href="/laporan/keuntungan" class="btn btn-primary tutup">Refresh</a>
            `)
         } else if ( $(this).find(':selected').data('jenis_cari') == 'harian' ) {
            $('#target').html(`
                <form action="/laporan/keuntungan_harian" method="get">
                    <div class="row">
                        <div class="col-md-1">
                            <label for="tanggal">Pilih Tanggal</label>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <input type="date" name="tanggal" class="form-control form-control-sm"
                                    id="tanggal" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary">Cari</button>
                            <a href="/laporan/keuntungan" class="btn btn-primary">Refresh</a>
                        </div>
                    </div>
                </form>
            `)
         } else if ( $(this).find(':selected').data('jenis_cari') == 'minggu_atau_bulan' ) {
            $('#target').html(`
                <form action="/laporan/keuntungan_minggu_atau_bulan" method="get">
                    <div class="row">
                        <div class="col-md-1">
                            <label>Pilih Tanggal</label>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <input type="date" name="tanggal_awal" class="form-control form-control-sm"
                                    id="tanggal_awal" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <input type="date" name="tanggal_akhir" class="form-control form-control-sm"
                                    id="tanggal_akhir" required>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary">Cari</button>
                            <a href="/laporan/keuntungan" class="btn btn-primary">Refresh</a>
                        </div>
                    </div>
                </form>
            `)
        } else {
            $('#target').html(``)
         }
		//  $('#harga').val($(this).find(':selected').data('harga'))
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/keuntungan.blade.php ENDPATH**/ ?>