
<?php $__env->startSection('header'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Kasir</a></li>
                        <li class="breadcrumb-item active"><?php echo e(auth()->user()->name); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header">
                            <strong>No Invoice: </strong><?php echo e(request()->segment(2)); ?>

                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Barcode</th>
                                        <th>Nama Barang</th>
                                        <th>Harga Barang</th>
                                        <th>QTY</th>
                                        <th>Total Harga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $total_pembayaran = 0;
                                    ?>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($item->barcode); ?></td>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e(rupiah($item->harga_jual)); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e(rupiah($item->total_harga)); ?></td>
                                        <td>
                                            <a href="/penjualan/tambah_qty/<?php echo e($item->id_penjualan); ?>"
                                                class="btn btn-success btn-sm">
                                                <i class="fas fa-plus"></i>
                                            </a>
                                            <a href="/penjualan/kurangi_qty/<?php echo e($item->id_penjualan); ?>"
                                                class="btn btn-warning text-white btn-sm">
                                                <i class="fas fa-minus"></i>
                                            </a>
                                            <a href="/penjualan/hapus/<?php echo e($item->id_penjualan); ?>"
                                                onclick="return confirm('Yakin mau dihapus?!')"
                                                class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                    $total_pembayaran = $total_pembayaran + $item->total_harga;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <form action="/penjualan" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="hidden" name="kode_penjualan" value="<?php echo e(request()->segment(2)); ?>">
                                    <input type="text" name="barcode" id="" class="form-control form-control-sm"
                                        placeholder="Masukan kode barcode" autofocus required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block btn-sm">Submit</button>
                                </div>
                            </form>
                            <hr>
                            <form name="form-simpan-transaksi">
                                <div class="form-group">
                                    <input type="hidden" name="" id="kode_penjualan"
                                        value="<?php echo e(request()->segment(2)); ?>">
                                    <input type="text" name="" id="" class="form-control form-control-sm"
                                        placeholder="Total Pembayaran" value="<?php echo e(rupiah($total_pembayaran)); ?>" readonly>
                                    <input type="hidden" name="total_pembayaran" id="total_pembayaran"
                                        value="<?php echo e($total_pembayaran); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="" id="pembayaran" class="form-control form-control-sm"
                                        placeholder="Pembayaran" autocomplete="off" onkeyup="kalkuklasi()" required>
                                    <input type="hidden" name="pembayaran" id="pembayaran1">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="" id="kembalian" class="form-control form-control-sm"
                                        placeholder="Kembalian" readonly>
                                    <input type="hidden" name="kembalian" id="kembalian1">
                                </div>
                                <div class="form-group">
                                    <button type="button" class="btn btn-primary btn-block btn-sm"
                                        id="btnSimpanTransaksi">Simpan
                                        Transaksi</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>

<script>
    $('#pembayaran').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
    })

    function kalkuklasi() {
        let pembayaran = $('#pembayaran').val().split('.'); // 300.000 -> 300 0000
        let pembayaran1 = $('#pembayaran1').val(pembayaran.join("")); // 300.000 -> 300 0000

        let total_pembayaran = $('#total_pembayaran').val();
        let hasil = pembayaran1.val() - total_pembayaran; // 210000
        let convert = parseInt(hasil).toLocaleString("id-ID"); // 210.000

        $('#kembalian').val(convert);
        $('#kembalian1').val(hasil);
    }

    $(document).on('click', '#btnSimpanTransaksi', function () {
        let _token = $('meta[name="csrf-token"]').attr('content');
        let kode_penjualan = $('#kode_penjualan').val();
        let total_pembayaran = $('#total_pembayaran').val();
        let pembayaran = $('#pembayaran').val();
        let pembayaran1 = $('#pembayaran1').val();
        let kembalian1 = $('#kembalian1').val();

        if (pembayaran == '') {
            alert('Pembayaran masih kosong');
            $('#pembayaran').addClass('is-invalid');
            $('#pembayaran').focus();
        } else {
            
        }

        $.ajax({
            url: '/penjualan/simpan_transaksi',
            type: 'post',
            data: {
                _token: _token,
                kode_penjualan: kode_penjualan,
                total_pembayaran: total_pembayaran,
                pembayaran: pembayaran1,
                kembalian: kembalian1,
            },
            success: function (result) {
                if (result.success == true) {
                    alert(result.message);
                    window.open('/penjualan/struk/' + kode_penjualan, '_blank');
                    window.location.href = '/penjualan/<?php echo e(no_invoice()); ?>';
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-laravel\resources\views/penjualan/index.blade.php ENDPATH**/ ?>