<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RASH - STOK BARANG</title>
    <style>
        body {
            font-size: 12px;
        }

        h3 {
            text-align: center;
            margin-top: 0px;
            margin-bottom: 5px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            color: #595959;
        }

        .section2 {
            width: 100%;
            height: 50px;
            font-family: calibri;
            background-color: #7E97AD;
            color: #fff;
        }

        .h2-section2 {
            margin-left: 20px;
            line-height: 50px;
        }

        .section3 {
            margin-top: 10px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table td,
        table th {
            border: 1px solid #ddd;
            padding: 8px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }

        table th {
            background-color: #5a5c69;
            color: #fff;
            text-align: left;
        }

        tr:nth-child(even) {
            background: #E5EAEE;
        }
    </style>
</head>

<body>
    <section class="section1">
        <h3>STOK BARANG</h3>
    </section>

    <section class="section3">
        <table>
            <tr>
                <th>#</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Minimal Stok</th>
            </tr>
            <?php
            $no = 1;
            $total_stok = 0;
            ?>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $total_stok += $item->stok;
            ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($item->kode_barang); ?></td>
                <td><?php echo e($item->nama_barang); ?></td>
                <td><?php echo e($item->kategori->nama); ?></td>
                <td><?php echo e($item->stok); ?></td>
                <td><?php echo e($item->stok_minimal); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align="center" colspan="4"><strong>Total Stok</strong></td>
                <td colspan="2"><?php echo e($total_stok); ?></td>
            </tr>
        </table>
    </section>
</body>

</html><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/stok_barang_download_pdf.blade.php ENDPATH**/ ?>