
<?php $__env->startSection('header'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Kasir</a></li>
                        <li class="breadcrumb-item active"><?php echo e(auth()->user()->name); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <?php if(session('warning')): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-warning alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h5><i class="icon fas fa-exclamation-triangle"></i> Perhatian! <?php echo e(session('warning')); ?></h5>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>No. Invoice : <strong><?php echo e(request()->segment(2)); ?></strong></h5>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <form action="/penjualan/detail_penjualan" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="no_invoice" id="no_invoice"
                                        value="<?php echo e(request()->segment(2)); ?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="kode_barang">Kode Barang</label>
                                            <select name="kode_barang" id="kode_barang" class="form-control select2bs4"
                                                required>
                                                <option value="" data-stok_barang="" data-harga_ecer=""
                                                    data-harga_grosir="" data-harga_agen="">Pilih</option>
                                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->kode_barang); ?>"
                                                    data-stok_barang="<?php echo e($item->stok); ?>"
                                                    data-harga_ecer="<?php echo e($item->harga_ecer); ?>"
                                                    data-harga_grosir="<?php echo e($item->harga_grosir); ?>"
                                                    data-harga_agen="<?php echo e($item->harga_agen); ?>"
                                                    data-profit_harga_ecer="<?php echo e($item->profit_harga_ecer); ?>"
                                                    data-profit_harga_grosir="<?php echo e($item->profit_harga_grosir); ?>"
                                                    data-profit_harga_agen="<?php echo e($item->profit_harga_agen); ?>">
                                                    <?php echo e($item->kode_barang); ?> -
                                                    <?php echo e($item->nama_barang); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <label for="harga">Pilih Jenis Harga</label>
                                            <select name="harga" id="harga" class="form-control select2bs4" required>
                                                <option value="">Pilih</option>
                                                <option value="" id="harga_ecer">
                                                    Ecer
                                                </option>
                                                <option value="" id="harga_grosir" data-profit_grosir="">
                                                    Grosir
                                                </option>
                                                <option value="" id="harga_agen" data-profit_agen="">
                                                    Agen
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label for="stok">Stok</label>
                                                <input type="text" class="form-control" id="stok" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label for="potongan">Potongan</label>
                                                <input type="text" class="form-control" id="potongan" autocomplete="off"
                                                    required>
                                                <input type="hidden" name="potongan" id="potongan1" required>
                                            </div>
                                        </div>
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label for="qty">QTY</label>
                                                <input type="text" name="qty" class="form-control" id="qty" required>
                                            </div>
                                        </div>
                                        <div class="col-md-1">
                                            <button type="submit" class="btn btn-primary"
                                                style="margin-top: 30px;">Tambahkan</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Detail Penjualan</h3>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered table-striped table-hover table-sm" id="datatable">
                                <thead class="bg-primary">
                                    <tr>
                                        <th>#</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Jenis</th>
                                        <th>Harga</th>
                                        <th>Item</th>
                                        <th>Potongan</th>
                                        <th>Total Harga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $total_keseluruhan_harga = 0;
                                    ?>
                                    <?php $__currentLoopData = $detail_penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    // $total_harga = $item->harga * $item->qty;
                                    $total_keseluruhan_harga += $item->total_harga;
                                    ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($item->kode_barang); ?></td>
                                        <td><?php echo e($item->nama_barang); ?></td>
                                        <td><?php echo e(ucfirst($item->jenis)); ?></td>
                                        <td><?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e(number_format($item->potongan, 0, ',', '.')); ?></td>
                                        <td><?php echo e(number_format($item->total_harga, 0, ',', '.')); ?></td>
                                        <td>
                                            <a href="/penjualan/<?php echo e($item->id); ?>/destroy"
                                                onclick="return confirm('Yakin mau dihapus?!')"
                                                class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <form action="/penjualan" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="no_invoice" value="<?php echo e(request()->segment(2)); ?>">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="total_pembayaran">Total Pembayaran</label>
                                                <input type="text" class="form-control form-control-lg"
                                                    id="total_pembayaran"
                                                    value="<?php echo e(number_format($total_keseluruhan_harga, 0, ',', '.')); ?>"
                                                    readonly required>
                                                <input type="hidden" name="total_pembayaran" id="total_pembayaran1"
                                                    value="<?php echo e($total_keseluruhan_harga); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="sub_total">Sub Total</label>
                                                <input type="text" class="form-control form-control-lg" id="sub_total"
                                                    readonly required>
                                                <input type="hidden" name="sub_total" id="sub_total1" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="kembalian">Kembalian</label>
                                                <input type="text" class="form-control form-control-lg" id="kembalian"
                                                    readonly required>
                                                <input type="hidden" name="kembalian" id="kembalian1" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="pelanggan_id">Pelanggan</label>
                                                <select name="pelanggan_id" id="pelanggan_id"
                                                    class="form-control select2bs4">
                                                    <option value="">Pilih</option>
                                                    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="jenis">Jenis Pembayaran</label>
                                                <select name="jenis" id="jenis" class="form-control" required>
                                                    <option value=""></option>
                                                    <option value="cash" id="jenis_cash">Cash</option>
                                                    <option value="transfer" id="jenis_transfer">Transfer</option>
                                                    <option value="hutang" id="jenis_hutang">Hutang</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="biaya_pengiriman">Biaya Pengiriman</label>
                                                <input type="text" class="form-control" id="biaya_pengiriman"
                                                    autocomplete="off" required>
                                                <input type="hidden" name="biaya_pengiriman" id="biaya_pengiriman1">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="pembayaran">Pembayaran</label>
                                                <input type="text" class="form-control" id="pembayaran"
                                                    onkeyup="kalkulasi()" autocomplete="off" required>
                                                <input type="hidden" name="pembayaran" id="pembayaran1">
                                            </div>
                                        </div>
                                    </div>
                                    <div id="target"></div>
                                    <div class="loading"></div>
                                    <button type="submit" id="btnSimpan" class="btn btn-primary btn-block">Simpan
                                        Transaksi</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>

<script>
    $(function () {  
        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })  
    })

    $(document).on('change', '#kode_barang', function() {
        if($(this).val() == '') {

        } else {
            $('#harga').trigger('change');

            $('#stok').val($(this).find(':selected').data('stok_barang'))

            $('#harga_ecer').val($(this).find(':selected').data('harga_ecer') + ",ecer")
            $('#harga_ecer').text("Ecer - Rp" + $(this).find(':selected').data('harga_ecer'))
            
            $('#harga_grosir').val($(this).find(':selected').data('harga_grosir') + ",grosir")
            $('#harga_grosir').text("Grosir - Rp" + $(this).find(':selected').data('harga_grosir'))

            $('#harga_agen').val($(this).find(':selected').data('harga_agen') + ",agen")
            $('#harga_agen').text("Agen - Rp" + $(this).find(':selected').data('harga_agen'))
        }
    })

    $(document).on('change', '#jenis', function() {
		//  alert($(this).find(':selected').val());
        if($(this).val() === 'transfer') {
          // $('#bank_lain').focus();
          $('#target').html(`
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group tutup">
                        <label for="jenis_bank">Bank</label>
                        <select name="jenis_bank" id="jenis_bank" class="form-control">
                            <option value="BRI">BRI</option>
                            <option value="BCA">BCA</option>
                            <option value="BNI">BNI</option>
                            <option value="MANDIRI">MANDIRI</option>
                            <option value="BJB">BJB</option>
                            <option value="BTN">BTN</option>
                        </select>
                    </div>                    
                </div>
                <div class="col-md-6">
                    <div class="form-group tutup">
                        <label for="bukti_transfer">Bukti Transfer</label>
                        <input type="file" name="bukti_transfer" class="form-control" id="bukti_transfer" required>
                    </div>
                </div>
            </div>
          `)
        } else {
            $('.tutup').remove();
        }
    })


    $('#pembayaran').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
    })

    $('#diskon').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let diskon1 = $(this).val().split('.');
        $('#diskon1').val(diskon1.join(""));
    })

    $('#biaya_pengiriman').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let biaya_pengiriman1 = $(this).val().split('.');
        $('#biaya_pengiriman1').val(biaya_pengiriman1.join(""));
    })

    $('#potongan').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let potongan1 = $(this).val().split('.');
        $('#potongan1').val(potongan1.join(""));
    })

    $(document).on('keyup', '#biaya_pengiriman', function () {
        let total_pembayaran1 = $('#total_pembayaran1').val();
        let biaya_pengiriman1 = $('#biaya_pengiriman1').val();
        let hasil = parseInt(biaya_pengiriman1) + parseInt(total_pembayaran1);
        let convert = parseInt(hasil).toLocaleString('id-ID');
        $('#sub_total').val(convert);
        $('#sub_total1').val(hasil);
    });

    // $(document).on('keyup', '#diskon', function() {
    //     let total_pembayaran1 = $('#total_pembayaran1').val();
    //     let biaya_pengiriman = $('#biaya_pengiriman1').val();
    //     let diskon = $('#diskon1').val();
    //     if ($(this).val() != 0) {
            
    //         let hasil = parseInt(total_pembayaran1) + parseInt(biaya_pengiriman) - parseInt(diskon);
    //         let convert = parseInt(hasil).toLocaleString("id-ID");

    //         $('#sub_total').val(convert);
    //         $('#sub_total1').val(hasil);
    //     } else {
    //         let hasil = parseInt(total_pembayaran1) + parseInt(biaya_pengiriman);
    //         let convert = parseInt(hasil).toLocaleString("id-ID");
    //         $('#sub_total').val(convert);
    //         $('#sub_total1').val(total_pembayaran1);
    //     }
    // })

    function kalkulasi() {
        let pembayaran = $('#pembayaran').val().split('.'); // 300.000 -> 300 0000
        let pembayaran1 = $('#pembayaran1').val(pembayaran.join("")); // 300.000 -> 300 0000
        
        // if (pembayaran == 0) {
        //     $('#kembalian').val(0);
        //     $('#kembalian1').val(0);
        //     $('#jenis_hutang').attr('selected', 'selected');
        // } else {
            let sub_total1 = $('#sub_total1').val();
            let hasil = pembayaran1.val() - sub_total1; // 210000
            let convert = parseInt(hasil).toLocaleString("id-ID"); // 210.000

            $('#kembalian').val(convert);
            $('#kembalian1').val(hasil);
        // }
    }
</script>

<script>
    $(document).on('click', '#btnSimpan', function () {
         let jenis = $('#jenis').val();
         let biaya_pengiriman = $('#biaya_pengiriman').val();
         let diskon = $('#diskon').val();
         let pembayaran = $('#pembayaran').val();
         let bukti_transfer = $('#bukti_transfer').val();
         let no_invoice = $('#no_invoice').val();

         if(jenis == '') {
             $('#jenis').addClass('is-invalid');
         } else if(biaya_pengiriman == '') {
             $('#biaya_pengiriman').addClass('is-invalid');
         } else if(diskon == '') {
             $('#diskon').addClass('is-invalid');
         } else if(pembayaran == '') {
             $('#pembayaran').addClass('is-invalid');
         } else if(bukti_transfer == '') {
             $('#bukti_transfer').addClass('is-invalid');
         }  else {
             $('#btnSimpan').addClass('d-none');
             $('.loading').html(`
                <button class="btn btn-primary btn-block" type="button" disabled>
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    Simpan Transaksi...
                </button>
             `);
         }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-rash\resources\views/penjualan/create.blade.php ENDPATH**/ ?>