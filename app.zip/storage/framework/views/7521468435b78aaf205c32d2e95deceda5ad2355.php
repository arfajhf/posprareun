

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <form action="/pengeluaran/update/<?php echo e($pengeluaran->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="no_pengeluaran">No Pengeluaran</label>
                                    <input type="text" name="no_pengeluaran" class="form-control form-control-sm"
                                        id="no_pengeluaran" value="<?php echo e($pengeluaran->no_pengeluaran); ?>" readonly
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nama Pengeluaran</label>
                                    <input type="text" name="nama" class="form-control form-control-sm" id="nama"
                                        value="<?php echo e($pengeluaran->nama); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="jumlah">Biaya</label>
                                    <input type="text" class="form-control form-control-sm" id="jumlah"
                                        value="<?php echo e($pengeluaran->jumlah); ?>" required>
                                    <input type="hidden" name="jumlah" id="jumlah1" value="<?php echo e($pengeluaran->jumlah); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="keterangan">Keterangan</label>
                                    <input type="text" name="keterangan" class="form-control form-control-sm"
                                        id="keterangan" value="<?php echo e($pengeluaran->keterangan); ?>" required>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm">Update</button>
                                <a href="/pengeluaran" class="btn btn-light btn-sm">kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    $('#jumlah').on('keyup', function () {
        $(this).mask('000.000.000', {reverse: true});
        let jumlah1 = $(this).val().split('.');
        $('#jumlah1').val(jumlah1.join(""));
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bisnisna/pos.preneur.co.id/resources/views/pengeluaran/edit.blade.php ENDPATH**/ ?>