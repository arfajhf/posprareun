

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Laporan <?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Laporan <?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <form action="/laporan/keuangan_cari" method="get">
                                <div class="row">
                                    <div class="col-md-1">
                                        <label>Pilih Tanggal</label>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal_awal" class="form-control form-control-sm"
                                                id="tanggal_awal" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <input type="date" name="tanggal_akhir" class="form-control form-control-sm"
                                                id="tanggal_akhir" required>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                        <a href="/laporan/keuangan" class="btn btn-primary">Refresh</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Tanggal : <?php echo e($tanggal_awal1); ?> Sampai <?php echo e($tanggal_akhir1); ?></strong>
                                </div>
                                <div class="col-md-6">
                                    <form action="/laporan/keuangan_download" method="post" target="
                                    _blank">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="tanggal_awal" value="<?php echo e($tanggal_awal2); ?>">
                                        <input type="hidden" name="tanggal_akhir" value="<?php echo e($tanggal_akhir2); ?>">
                                        <button type="submit" class="btn btn-success float-right">Download PDF</button>
                                    </form>
                                </div>
                            </div>
                            <table class="table table-bordered mt-2">
                                <tr>
                                    <th>Total Keuntungan</th>
                                    <td><?php echo e(number_format($total_keuntungan, 0, ',', '.')); ?></td>
                                </tr>
                                <tr>
                                    <th>Total Pengeluaran</th>
                                    <td><?php echo e(number_format($total_pengeluaran, 0, ',', '.')); ?></td>
                                </tr>
                                <tr>
                                    <th>Keuntungan Bersih</th>
                                    <?php
                                    $keuntungan_bersih = $total_keuntungan - $total_pengeluaran;
                                    ?>
                                    <td><?php echo e(number_format($keuntungan_bersih, 0, ',', '.')); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php if(session('success')): ?>
<script type="text/javascript">
    $(function() {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

      Toast.fire({
          icon: 'success',
          title: "<?php echo e(session('success')); ?>"
        })
    });  
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/keuangan_cari.blade.php ENDPATH**/ ?>