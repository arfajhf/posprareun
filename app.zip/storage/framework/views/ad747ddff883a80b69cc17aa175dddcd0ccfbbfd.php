

<?php $__env->startSection('konten'); ?>
<div class="content-wrapper" style="min-height: 1200.88px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo e($title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Edit <?php echo e($title); ?></h3>
                        </div>
                        <form action="/pembelian/detail/update/<?php echo e($detail_pembelian->id); ?>" method="POST">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="no_pembelian">No Pembelian</label>
                                    <input type="text" name="no_pembelian" class="form-control"
                                        value="<?php echo e($detail_pembelian->no_pembelian); ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="kode_barang">Kode Barang</label>
                                    <select name="kode_barang" id="kode_barang" class="form-control select2bs4"
                                        required>
                                        <option value="">Pilih</option>
                                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->kode_barang); ?>"
                                            <?php echo e($detail_pembelian->kode_barang == $item->kode_barang ? 'selected' : ''); ?>>
                                            <?php echo e($item->kode_barang); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="qty">QTY</label>
                                    <input type="text" name="qty" class="form-control"
                                        value="<?php echo e($detail_pembelian->qty); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="total_harga">Total Harga</label>
                                    <input type="text" class="form-control" id="total_harga"
                                        value="<?php echo e($detail_pembelian->total_harga); ?>">
                                    <input type="hidden" name="total_harga" id="total_harga1"
                                        value="<?php echo e($detail_pembelian->total_harga); ?>" required>
                                </div>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="/pembelian/detail/<?php echo e(request()->segment(4)); ?>"
                                    class="btn btn-light">kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    $(function () {  
        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })  
    })

    $('#total_harga').on('keyup', function () {
        let total_harga = $(this).mask('000.000.000', {reverse: true});
        let total_harga1 = total_harga.val().split('.').join("");
        $('#total_harga1').val(total_harga1);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\pos-laravel-pak-fazar\resources\views/pembelian_barang/edit_pembelian.blade.php ENDPATH**/ ?>