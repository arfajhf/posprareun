<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RASH</title>
    <style>
        body {
            font-size: 12px;
        }

        h3 {
            text-align: right;
            margin-top: 0px;
            margin-bottom: 5px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            color: #595959;
        }

        .section2 {
            width: 100%;
            height: 50px;
            font-family: calibri;
            background-color: #7E97AD;
            color: #fff;
        }

        .h2-section2 {
            margin-left: 20px;
            line-height: 50px;
        }

        .section3 {
            margin-top: 10px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table td,
        table th {
            border: 1px solid #ddd;
            padding: 8px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }

        table th {
            background-color: #5a5c69;
            color: #fff;
            text-align: left;
        }

        tr:nth-child(even) {
            background: #E5EAEE;
        }
    </style>
</head>

<body>
    <section class="section1">
        <a href="/laporan/detail_penjualan_download/<?php echo e($penjualan->no_invoice); ?>" target="_blank"><button
                type="button">Download</button></a>
        <p style="color: #595959; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">
            Tanggal <span style="margin-left: 42px;">:</span>
            <strong style="color: #595959;"><?php echo e(date('d-m-Y', strtotime($penjualan->created_at))); ?></strong>
        </p>
        <p style="color: #595959; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">
            No. Invoice <span style="margin-left: 25px;">:</span> <strong
                style="color: #595959;"><?php echo e($penjualan->no_invoice); ?></strong>
        </p>
        <p style="color: #595959; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">
            Pelanggan <span style="margin-left: 26px;">:</span>
            <?php if($penjualan->pelanggan_id == ''): ?>
            <strong style="color: #595959;">Umum</strong>

            <?php else: ?>
            <strong style="color: #595959;"><?php echo e($penjualan->pelanggan->nama); ?></strong>
            <?php endif; ?>
        </p>
        <p style="color: #595959; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">
            Jenis Penjualan : <strong style="color: #595959;"><?php echo e(ucfirst($penjualan->jenis)); ?></strong>
        </p>
        <?php if($penjualan->jenis_bank == ''): ?>

        <?php else: ?>
        <p style="color: #595959; font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">
            Nama Bank <span style="margin-left: 20px;">:</span> <strong
                style="color: #595959;"><?php echo e($penjualan->jenis_bank); ?></strong>
        </p>
        <?php endif; ?>
    </section>

    <section class="section3">
        <table>
            <tr>
                <th>NO</th>
                <th>KODE BARANG</th>
                <th>NAMA BARANG</th>
                <th>JENIS PENJUALAN</th>
                <th>HARGA</th>
                <th>ITEM</th>
                <th>POTONGAN</th>
                <th>TOTAL HARGA</th>
            </tr>
            <?php
            $no = 1;
            ?>
            <?php $__currentLoopData = $detail_penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($item->kode_barang); ?></td>
                <td><?php echo e($item->nama_barang); ?></td>
                <td><?php echo e(ucfirst($item->jenis)); ?></td>
                <td><?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                <td><?php echo e($item->qty); ?></td>
                <td><?php echo e(number_format($item->potongan, 0, ',', '.')); ?></td>
                <td><?php echo e(number_format($item->total_harga, 0, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="7"><strong>Total Penjualan</strong></td>
                <td><?php echo e(number_format($penjualan->total_pembayaran, 0, ',', '.')); ?></td>
            </tr>
            <tr>
                <td colspan="7"><strong>Biaya Pengiriman</strong></td>
                <td><?php echo e(number_format($penjualan->biaya_pengiriman, 0, ',', '.')); ?></td>
            </tr>
            <tr>
                <td colspan="7"><strong>Sub Total</strong></td>
                <td><?php echo e(number_format($penjualan->sub_total, 0, ',', '.')); ?></td>
            </tr>
            <tr>
                <td colspan="7"><strong>Tunai</strong></td>
                <td><?php echo e(number_format($penjualan->pembayaran, 0, ',', '.')); ?></td>
            </tr>
            <tr>
                <td colspan="7"><strong>Kembalian</strong></td>
                <td><?php echo e(number_format($penjualan->kembalian, 0, ',', '.')); ?></td>
            </tr>
        </table>
    </section>
</body>

</html><?php /**PATH E:\laravel\pos-rash\resources\views/laporan/detail_penjualan.blade.php ENDPATH**/ ?>