<!DOCTYPE html>
<html>

<head>
    <title>CHILS OFFICIAL - {{ $penjualan->no_invoice }}</title>
    <style>
        body {
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            color: #595959;
        }

        table {
            border-collapse: collapse;
        }

        .footer {
            display: flex;
            justify-content: space-between;
        }

        @media print {
            @page {
                width: 80mm;
                margin: 0mm
            }

            a {
                display: none;
            }
        }
    </style>
</head>

<body onload="window.print()">

    <a href="/penjualan/{{ no_invoice() }}">Kembali</a>
    <h5>CHILS OFFICIAL</h5>
    <h5 style="margin-top: -20px">Jl. Ibu Apipah  No.6D Kel.Kahuripan Kec. Tawang  Kota Tasikmalaya</h5>

    <table border="0" style="margin-top: -20px;">
        <tr>
            <th align="left">Tanggal</th>
            <td>:</td>
            <td>{{ date('d/m/Y H:i:s', strtotime($penjualan->created_at)) }}</td>
        </tr>
        <tr>
            <th align="left">Kasir</th>
            <td>:</td>
            <td>{{ $penjualan->user->name }}</td>
        </tr>
        <tr>
            <th align="left">No. Invoice</th>
            <td>:</td>
            <td>{{ $penjualan->no_invoice }}</td>
        </tr>
        <tr>
            <th align="left">Pelanggan</th>
            <td>:</td>
            @if ($penjualan->pelanggan_id == '')
            <td>Umum</td>
            @else
            <td>{{ $penjualan->pelanggan->nama }}</td>
            @endif
        </tr>
        <tr>
            <th align="left">Jenis</th>
            <td>:</td>
            <td>{{ ucfirst($penjualan->jenis) }}</td>
        </tr>
        <tr>
            <th align="left">Bank</th>
            <td>:</td>
            <td>{{ ucfirst($penjualan->jenis_bank) }}</td>
        </tr>
    </table>

    <table border="1" width="100%" style="margin-top: 10px;">
        <tr>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">No</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">KODE BARANG</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">NAMA BARANG</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">JENIS</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">HARGA</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">ITEM</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">POTONGAN</th>
            <th align="left" style="border: 2px dashed #aaa; padding: 8px;">TOTAL HARGA</th>
        </tr>
        @php
        $no = 1;
        @endphp
        @foreach ($detail_penjualan as $item)
        <tr>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ $no++ }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ $item->kode_barang }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ $item->nama_barang }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ ucfirst($item->jenis) }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ number_format($item->harga, 0, ',', '.') }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ $item->qty }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ number_format($item->potongan, 0, ',', '.') }}</td>
            <td style="border: 2px dashed #aaa; padding: 8px;">{{ number_format($item->total_harga, 0, ',', '.') }}</td>
        </tr>
        @endforeach
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">JUMLAH</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong>{{ number_format($penjualan->total_pembayaran, 0, ',', '.') }}</strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">BIAYA PENGIRIMAN</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong>{{ number_format($penjualan->biaya_pengiriman, 0, ',', '.') }}</strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">SUB TOTAL</th>
            <td style="border: 2px dashed #fff; padding: 8px;">

                <strong>{{ number_format($penjualan->sub_total, 0, ',', '.') }}</strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">TUNAI</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong>{{ number_format($penjualan->pembayaran, 0, ',', '.') }}</strong></td>
        </tr>
        <tr>
            <th align="right" style="border: 2px dashed #fff; padding: 8px;" colspan="7">KEMBALIAN</th>
            <td style="border: 2px dashed #fff; padding: 8px;">
                <strong>{{ number_format($penjualan->kembalian, 0, ',', '.') }}</strong></td>
        </tr>
    </table>

    <div class="footer">
        <ul>
            <li>Barang yang rusak dapat dikembalian dengan syarat tertentu</li>
            <li>Selamat berbelanja kembali</li>
            <li>Terima kasih</li>
        </ul>
    </div>



</body>

</html>