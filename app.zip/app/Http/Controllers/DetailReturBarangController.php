<?php

namespace App\Http\Controllers;

use App\DetailReturBarang;
use Illuminate\Http\Request;

class DetailReturBarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DetailReturBarang  $detailReturBarang
     * @return \Illuminate\Http\Response
     */
    public function show(DetailReturBarang $detailReturBarang)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DetailReturBarang  $detailReturBarang
     * @return \Illuminate\Http\Response
     */
    public function edit(DetailReturBarang $detailReturBarang)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DetailReturBarang  $detailReturBarang
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetailReturBarang $detailReturBarang)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DetailReturBarang  $detailReturBarang
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetailReturBarang $detailReturBarang)
    {
        //
    }
}
