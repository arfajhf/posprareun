<?php

namespace App\Http\Controllers;

use App\Barang;
use App\Kategori;
use App\StokBarang;
use Illuminate\Http\Request;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Barang';
        $barang = Barang::orderBy('id', 'desc')->get();
        return view('barang.index', compact('title', 'barang'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Barang';
        $kategori = Kategori::all();
        return view('barang.create', compact('title', 'kategori'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'kode_barang' => 'unique:barang'
        ], [
            'kode_barang.unique' => 'kode barang sudah ada'
        ]);
        Barang::create($request->all());
        return redirect('/barang')->with('success', 'Data barang berhasil tersimpan');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $title = 'Barang';
        $barang = Barang::find($id);
        $kategori = Kategori::all();
        return view('barang.edit', compact('title', 'barang', 'kategori'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $barang = Barang::find($id);
        $barang->kode_barang = $request->kode_barang;
        $barang->kategori_id = $request->kategori_id;
        $barang->nama_barang = $request->nama_barang;
        $barang->harga_beli = $request->harga_beli;
        $barang->harga_ecer = $request->harga_ecer;
        $barang->harga_grosir = $request->harga_grosir;
        $barang->harga_agen = $request->harga_agen;
        $barang->profit_harga_ecer = $request->profit_harga_ecer;
        $barang->profit_harga_grosir = $request->profit_harga_grosir;
        $barang->profit_harga_agen = $request->profit_harga_agen;
        $barang->deskripsi = $request->deskripsi;
        $barang->stok = $request->stok;
        $barang->stok_minimal = $request->stok_minimal;
        $barang->save();
        return redirect('/barang')->with('success', 'Data barang berhasil terupdate');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Barang  $barang
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $barang = Barang::find($id);
        $barang->delete();
        return redirect('/barang')->with('success', 'Data barang berhasil terhapus');
    }
}
